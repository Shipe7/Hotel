<?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'Front Desk']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Front Desk']); ?>
    <!--begin::Content container-->
     <?php $__env->slot('buttons', null, []); ?> 
        <span class="bg-primary text-white rounded py-2 px-3">Confirmed</span>
        <span class="bg-success text-white rounded py-2 px-3">Checked In</span>
        <span class="bg-warning text-white rounded py-2 px-3">Checked Out</span>
        <span class="bg-secondary text-white rounded py-2 px-3">Due In</span>
        <span class="bg-danger text-white rounded py-2 px-3">Due Out</span>
     <?php $__env->endSlot(); ?>
    <div id="kt_app_content_container" class="app-container container-fluid">
        <!--begin::Card-->
        <div class="card">
            <div class="card-header">
                <div class="d-flex align-items-center">
                    <h2 class="card-title text-gray-700 fs-4 me-4">From</h2>
                    <div class="input-group input-group-">
                        <span class="input-group-text">
                            <i class="ki-duotone ki-calendar fs-2">
                                <i class="path1"></i><i class="path2"></i>
                            </i>
                        </span>
                        <input class="form-control w-125px" placeholder="<?php echo e(now()->format('d/m/Y')); ?>" id="from-date" readonly/>
                    </div>
                    <div class="ms-6 position-relative my-1">
                        <select id="rooms" class="form-select form-select-solid w-175px" aria-label="Category">
                            <option value="<?php echo e(route('api.calendar-rooms.index')); ?>">All Reservations</option>
                            <?php $__currentLoopData = $roomTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e(route('api.calendar-rooms.index', ['type' => $type])); ?>"><?php echo e($type->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="card-toolbar">
                    <div class="d-flex align-items-center position-relative my-1">
                        <i class="ki-duotone ki-magnifier fs-3 position-absolute ms-4">
                            <i class="path1"></i><i class="path2"></i>
                        </i>
                        <input data-kt-ecommerce-product-filter="search" class="form-control form-control- form-control-solid w-275px ps-12" placeholder="Search" id="search">
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div id='calendar'></div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('plugins/custom/fullcalendar/fullcalendar-scheduler.js')); ?>"></script>
        <?php echo $__env->make('front-desk.partials.calendar-styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('front-desk.partials.calendar-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script>
            $("#from-date").flatpickr({dateFormat: "d/m/Y"});
        </script>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\mall\resources\views/front-desk/index.blade.php ENDPATH**/ ?>