<span
    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'fw-bold fs-8 px-2 py-1 ms-2 badge',
        'badge-light-success' => $user->isAdmin(),
        'badge-light-warning' => ! $user->isAdmin(),
    ]); ?>">
    <?php echo e(ucfirst($user->type)); ?>

</span>
<?php /**PATH C:\xampp\htdocs\mall\resources\views/components/users/badge.blade.php ENDPATH**/ ?>