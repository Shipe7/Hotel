<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['title' => '', 'rating' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['title' => '', 'rating' => '']); ?>
<?php foreach (array_filter((['title' => '', 'rating' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<ul class="mb-0 ps-0">
    <?php echo e($title); ?>

    <li class="list-inline-item me-0">
        <i class="<?php echo e($rating >= 1 ? 'fa' : 'far'); ?> <?php echo e($rating > 0 && $rating < 1 ? 'fa-star-half-alt' : 'fa-star'); ?> text-warning fs-9"></i>
    </li>
    <li class="list-inline-item me-0">
        <i class="<?php echo e($rating >= 2 ? 'fa' : 'far'); ?> <?php echo e($rating > 1 && $rating < 2 ? 'fa-star-half-alt' : 'fa-star'); ?> text-warning fs-9"></i>
    </li>
    <li class="list-inline-item me-0">
        <i class="<?php echo e($rating >= 3 ? 'fa' : 'far'); ?> <?php echo e($rating > 2 && $rating < 3 ? 'fa-star-half-alt' : 'fa-star'); ?> text-warning fs-9"></i>
    </li>
    <li class="list-inline-item me-0">
        <i class="<?php echo e($rating >= 4 ? 'fa' : 'far'); ?> <?php echo e($rating > 3 && $rating < 4 ? 'fa-star-half-alt' : 'fa-star'); ?> text-warning fs-9"></i>
    </li>
    <li class="list-inline-item me-0">
        <i class="<?php echo e($rating >= 5 ? 'fa' : 'far'); ?> <?php echo e($rating > 4 && $rating < 5 ? 'fa-star-half-alt' : 'fa-star'); ?> text-warning fs-9"></i>
    </li>
    <?php echo e($slot); ?>

</ul>
<?php /**PATH C:\xampp\htdocs\mall\resources\views/components/app/review-rating.blade.php ENDPATH**/ ?>