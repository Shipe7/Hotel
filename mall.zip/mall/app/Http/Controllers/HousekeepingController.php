<?php

namespace App\Http\Controllers;
use App\Models\Housekeeping;

use Illuminate\Http\Request;

class HousekeepingController extends Controller
{
    //
    public function index()
    {
        $tableData = Housekeeping::all();
        // return view('housekeeping.index');
        
        return view('housekeeping.index', ['tableData' => $tableData]);
    }
}
