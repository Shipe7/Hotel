<svg width="465" height="26" viewBox="0 0 465 26" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="465" height="26" rx="4" fill="#003E85" fill-opacity="0.24"/>
    <text fill="#001A37" xml:space="preserve" style="white-space: pre" font-family="sans-serif" font-size="12" letter-spacing="0.2px"><tspan x="4" y="17.53">Booking details</tspan></text>
    <text fill="#001A37" xml:space="preserve" style="white-space: pre" font-family="sans-serif" font-size="12" letter-spacing="0.2px"><tspan x="105.833" y="17.53">0 room(s) </tspan></text>
    <text fill="#001A37" xml:space="preserve" style="white-space: pre" font-family="sans-serif" font-size="12" letter-spacing="0.2px"><tspan x="174.667" y="17.53">. 0 adult(s) </tspan></text>
    <text fill="#001A37" xml:space="preserve" style="white-space: pre" font-family="sans-serif" font-size="12" letter-spacing="0.2px"><tspan x="249.5" y="18.285">. 0 kid(s) </tspan></text>
    <text fill="#001A37" xml:space="preserve" style="white-space: pre" font-family="sans-serif" font-size="12" letter-spacing="0.2px"><tspan x="319.333" y="17.53">. $0.00</tspan></text>
    <text fill="#003E85" xml:space="preserve" style="white-space: pre" font-family="sans-serif" font-size="12" letter-spacing="0.2px"><tspan x="372.167" y="17.53">Change</tspan></text>
    <text fill="#A71C1F" xml:space="preserve" style="white-space: pre" font-family="sans-serif" font-size="12" letter-spacing="0.2px"><tspan x="431" y="17.53">Clear</tspan></text>
</svg>
